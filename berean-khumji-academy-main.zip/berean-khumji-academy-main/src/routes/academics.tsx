import { createFileRoute } from "@tanstack/react-router";
import { PageHero, Section, Card, Placeholder, meta } from "@/components/site";
import { images } from "@/lib/school";

export const Route = createFileRoute("/academics")({
  head: () => meta("Academics", "Classes, curriculum, teaching methods and assessment at Berean Baptist Academy, Noney, Manipur."),
  component: Academics,
});

function Academics() {
  return (
    <>
      <PageHero eyebrow="Academics" title="Strong foundations for every learner" image={images.classroom} />
      <Section eyebrow="Levels" title="Classes & academic levels">
        <div className="grid gap-5 md:grid-cols-3">
          {["Pre-primary", "Primary", "Middle / Secondary"].map((l) => <Card key={l} title={l}><Placeholder>Classes covered TBC</Placeholder></Card>)}
        </div>
      </Section>
      <Section tone="sage" eyebrow="Approach" title="Curriculum & teaching">
        <div className="grid gap-5 md:grid-cols-2">
          <Card title="Curriculum"><Placeholder>Board & syllabus TBC</Placeholder></Card>
          <Card title="Teaching methodology"><Placeholder /></Card>
          <Card title="Examinations & assessment"><Placeholder /></Card>
          <Card title="Learning resources"><Placeholder /></Card>
        </div>
      </Section>
      <Section tone="white" eyebrow="Calendar & Faculty" title="The year ahead">
        <div className="grid gap-5 md:grid-cols-2">
          <Card title="Academic calendar"><Placeholder>Calendar to be published</Placeholder></Card>
          <Card title="Our faculty"><Placeholder>Teacher profiles to be provided</Placeholder></Card>
        </div>
      </Section>
    </>
  );
}
