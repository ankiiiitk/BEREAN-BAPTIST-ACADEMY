import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { X } from "lucide-react";
import { PageHero, Section, meta } from "@/components/site";
import { images } from "@/lib/school";

export const Route = createFileRoute("/gallery")({
  head: () => meta("Gallery", "Photos of campus, classrooms, cultural events, sports and celebrations at Berean Baptist Academy."),
  component: Gallery,
});

const cats = ["All", "Campus", "Classrooms", "Cultural events", "Sports", "Annual functions", "Celebrations", "Student activities"];
const photos = [
  { src: images.hero, cat: "Campus", alt: "Campus in the morning mist" },
  { src: images.classroom, cat: "Classrooms", alt: "Students at their desks" },
  { src: images.culture, cat: "Cultural events", alt: "Traditional dance performance" },
  { src: images.sports, cat: "Sports", alt: "Football on the school ground" },
  { src: images.culture, cat: "Annual functions", alt: "Annual function performance" },
  { src: images.sports, cat: "Student activities", alt: "Students playing outdoors" },
];

function Gallery() {
  const [cat, setCat] = useState("All");
  const [open, setOpen] = useState<(typeof photos)[number] | null>(null);
  useEffect(() => {
    const k = (e: KeyboardEvent) => e.key === "Escape" && setOpen(null);
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, []);
  const shown = photos.filter((p) => cat === "All" || p.cat === cat);
  return (
    <>
      <PageHero eyebrow="Gallery" title="Moments from school life" intro="Sample images shown — authentic school photographs will replace them." image={images.culture} />
      <Section>
        <div className="mb-8 flex flex-wrap gap-2" role="tablist">
          {cats.map((c) => (
            <button key={c} role="tab" aria-selected={cat === c} onClick={() => setCat(c)}
              className={`rounded-full px-4 py-2 font-nav text-sm font-medium ${cat === c ? "bg-primary text-primary-foreground" : "border bg-card text-slate hover:border-gold"}`}>{c}</button>
          ))}
        </div>
        {shown.length === 0 ? (
          <p className="rounded-2xl border border-dashed p-10 text-center text-muted-foreground">Photos for this category coming soon.</p>
        ) : (
          <div className="columns-1 gap-5 sm:columns-2 lg:columns-3">
            {shown.map((p, i) => (
              <button key={i} onClick={() => setOpen(p)} className="group mb-5 block w-full overflow-hidden rounded-2xl">
                <img src={p.src} alt={p.alt} loading="lazy" width={1200} height={912} className={`w-full object-cover transition-transform duration-700 group-hover:scale-105 ${i % 2 ? "aspect-[3/4]" : "aspect-[4/3]"}`} />
              </button>
            ))}
          </div>
        )}
      </Section>
      {open && (
        <div role="dialog" aria-modal="true" aria-label={open.alt} className="fixed inset-0 z-[60] grid place-items-center bg-primary/95 p-5" onClick={() => setOpen(null)}>
          <button aria-label="Close" className="absolute top-5 right-5 text-primary-foreground"><X size={32} /></button>
          <figure onClick={(e) => e.stopPropagation()}>
            <img src={open.src} alt={open.alt} className="max-h-[80vh] rounded-2xl" />
            <figcaption className="mt-3 text-center text-primary-foreground/80">{open.alt}</figcaption>
          </figure>
        </div>
      )}
    </>
  );
}
