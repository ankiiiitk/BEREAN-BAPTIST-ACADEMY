import { createFileRoute } from "@tanstack/react-router";
import { FileDown } from "lucide-react";
import { PageHero, Section, Card, Placeholder, meta } from "@/components/site";
import { EnquiryForm, admissionSchema } from "@/components/forms";
import { images } from "@/lib/school";

export const Route = createFileRoute("/admissions")({
  head: () => meta("Admissions", "Admission procedure, eligibility, documents, fees and online enquiry for Berean Baptist Academy, Khumji, Manipur."),
  component: Admissions,
});

const steps = ["Submit an enquiry", "Visit the school office", "Submit the application form & documents", "Interaction / assessment", "Confirmation & fee payment"];

function Admissions() {
  return (
    <>
      <PageHero eyebrow="Admissions" title="Join the Berean family" intro="Everything you need to know to enrol your child." image={images.hero} />
      <Section eyebrow="Procedure" title="How admission works">
        <ol className="grid gap-4 md:grid-cols-5">
          {steps.map((s, i) => (
            <li key={s} className="rounded-2xl border bg-card p-6"><span className="font-display text-4xl text-gold">0{i + 1}</span><p className="mt-2 font-nav text-sm font-medium text-slate">{s}</p></li>
          ))}
        </ol>
        <p className="mt-4 text-sm text-muted-foreground">Indicative steps <Placeholder>to be confirmed by the school</Placeholder></p>
      </Section>
      <Section tone="sage" eyebrow="Requirements" title="Eligibility, documents & fees">
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          <Card title="Eligibility & age"><Placeholder /></Card>
          <Card title="Required documents"><ul className="list-disc space-y-1 pl-5"><li>Birth certificate</li><li>Previous school records</li><li>Passport photos</li></ul><Placeholder>Final list TBC</Placeholder></Card>
          <Card title="Fee structure"><Placeholder>Fees TBC</Placeholder></Card>
          <Card title="Admission dates"><Placeholder>Dates TBC</Placeholder></Card>
        </div>
        <button disabled className="mt-8 inline-flex cursor-not-allowed items-center gap-2 rounded-full border border-primary px-6 py-3 font-nav text-sm font-medium text-primary opacity-70"><FileDown size={16} /> Application form (coming soon)</button>
      </Section>
      <Section id="enquiry" eyebrow="Enquire Online" title="Admission enquiry form">
        <EnquiryForm schema={admissionSchema} submitLabel="Submit Enquiry" fields={[
          { name: "student", label: "Student name", required: true },
          { name: "dob", label: "Date of birth", type: "date", required: true },
          { name: "parent", label: "Parent / guardian name", required: true },
          { name: "klass", label: "Class applying for", required: true, options: ["Nursery", "LKG", "UKG", ...Array.from({ length: 10 }, (_, i) => `Class ${i + 1}`)] },
          { name: "phone", label: "Contact number", type: "tel", required: true },
          { name: "email", label: "Email address", type: "email", required: true },
          { name: "current", label: "Current school" },
          { name: "message", label: "Additional message", textarea: true },
        ]} />
      </Section>
    </>
  );
}
