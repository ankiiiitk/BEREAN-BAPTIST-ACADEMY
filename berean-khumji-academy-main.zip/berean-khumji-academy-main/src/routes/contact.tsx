import { createFileRoute } from "@tanstack/react-router";
import { MapPin, Phone, Mail, Clock, MessageCircle } from "lucide-react";
import { PageHero, Section, meta } from "@/components/site";
import { EnquiryForm, contactSchema } from "@/components/forms";
import { images, school } from "@/lib/school";

export const Route = createFileRoute("/contact")({
  head: () => meta("Contact Us", "Address, phone, email, office hours and map for Berean Baptist Academy, Khumji, Noney District, Manipur."),
  component: Contact,
});

function Contact() {
  const rows = [[MapPin, school.address], [Phone, school.phone], [Mail, school.email], [Clock, school.hours]] as const;
  return (
    <>
      <PageHero eyebrow="Contact" title="We'd love to hear from you" image={images.hero} />
      <Section>
        <div className="grid gap-10 lg:grid-cols-[1fr_1.4fr]">
          <div className="space-y-5">
            {rows.map(([I, t], i) => <div key={i} className="flex gap-4 rounded-2xl border bg-card p-5"><I className="shrink-0 text-gold" /><span className="break-words text-slate">{t}</span></div>)}
            <a href={`https://wa.me/${school.whatsapp}`} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 font-nav font-medium text-primary-foreground"><MessageCircle size={18} /> Chat on WhatsApp</a>
          </div>
          <EnquiryForm schema={contactSchema} submitLabel="Send Message" fields={[
            { name: "name", label: "Your name", required: true },
            { name: "email", label: "Email", type: "email", required: true },
            { name: "phone", label: "Phone", type: "tel" },
            { name: "message", label: "Message", textarea: true, required: true },
          ]} />
        </div>
        <iframe title="Map to Berean Baptist Academy" loading="lazy" className="mt-12 h-96 w-full rounded-2xl border"
          src={`https://www.google.com/maps?q=${encodeURIComponent(school.mapQuery)}&output=embed`} />
      </Section>
    </>
  );
}
