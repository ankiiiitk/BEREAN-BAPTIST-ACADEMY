import { createFileRoute } from "@tanstack/react-router";
import { PageHero, Section, Card, Placeholder, meta } from "@/components/site";
import { images } from "@/lib/school";

export const Route = createFileRoute("/student-life")({
  head: () => meta("Student Life", "Culture, sports, music, clubs and celebrations — including Manipuri traditions — at Berean Baptist Academy."),
  component: StudentLife,
});

function StudentLife() {
  return (
    <>
      <PageHero eyebrow="Student Life" title="Beyond the classroom" intro="Celebrating the traditions of Manipur and the talents of every child." image={images.culture} />
      <Section eyebrow="Heritage" title="Our culture, our identity">
        <div className="grid items-center gap-10 md:grid-cols-2">
          <img src={images.culture} alt="Students in traditional attire performing a dance" loading="lazy" width={1200} height={912} className="rounded-2xl object-cover shadow-soft" />
          <p className="text-lg text-muted-foreground">Regional festivals, traditional dance and local customs are part of school life. Specific festivals and programmes celebrated <Placeholder /></p>
        </div>
      </Section>
      <Section tone="sage" eyebrow="Activities" title="Something for everyone">
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {["Cultural activities", "Sports & athletics", "Music & dance", "Arts & crafts", "Annual celebrations", "Competitions", "Excursions", "Clubs"].map((t) => <Card key={t} title={t}><Placeholder>Details TBC</Placeholder></Card>)}
        </div>
      </Section>
    </>
  );
}
