import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { FileText } from "lucide-react";
import { PageHero, Section, Placeholder, meta } from "@/components/site";
import { images, announcements } from "@/lib/school";

export const Route = createFileRoute("/news")({
  head: () => meta("News & Announcements", "Notices, holidays, exam schedules, admissions news and circulars from Berean Baptist Academy."),
  component: News,
});

const cats = ["All", "Notices", "Holidays", "Examinations", "Admissions", "Events", "Results"];

function News() {
  const [cat, setCat] = useState("All");
  const list = announcements.filter((a) => cat === "All" || a.cat === cat);
  return (
    <>
      <PageHero eyebrow="News" title="Notices & announcements" image={images.classroom} />
      <Section>
        <div className="mb-8 flex flex-wrap gap-2">
          {cats.map((c) => <button key={c} aria-pressed={cat === c} onClick={() => setCat(c)} className={`rounded-full px-4 py-2 font-nav text-sm font-medium ${cat === c ? "bg-primary text-primary-foreground" : "border bg-card text-slate"}`}>{c}</button>)}
        </div>
        <div className="space-y-4">
          {list.length === 0 && <p className="text-muted-foreground">No announcements in this category yet.</p>}
          {list.map((a) => (
            <article key={a.title} className="flex flex-col gap-2 rounded-2xl border bg-card p-6 md:flex-row md:items-center md:gap-8">
              <span className="eyebrow md:w-36">{a.cat}</span>
              <div className="flex-1"><h3 className="text-2xl">{a.title}</h3><p className="text-muted-foreground">{a.body}</p></div>
              <Placeholder>{a.date}</Placeholder>
            </article>
          ))}
        </div>
      </Section>
      <Section tone="sage" eyebrow="Downloads" title="Circulars & documents">
        <div className="flex items-center gap-4 rounded-2xl border bg-card p-6 text-muted-foreground"><FileText className="text-gold" /> Downloadable circulars will be listed here. <Placeholder /></div>
      </Section>
    </>
  );
}
