import { createFileRoute } from "@tanstack/react-router";
import { School, FlaskConical, Monitor, Library, Trophy, TreePine, Bus, HeartPulse, Home } from "lucide-react";
import { PageHero, Section, Card, Placeholder, meta } from "@/components/site";
import { images } from "@/lib/school";

export const Route = createFileRoute("/facilities")({
  head: () => meta("Infrastructure & Facilities", "Classrooms, labs, library, sports grounds and more at Berean Baptist Academy, Noney District."),
  component: Facilities,
});

const items = [
  [School, "Classrooms"], [FlaskConical, "Science laboratory"], [Monitor, "Computer laboratory"],
  [Library, "Library"], [Trophy, "Sports facilities"], [TreePine, "Playground"],
  [Bus, "Transportation"], [HeartPulse, "Medical & first aid"], [Home, "Hostel (if available)"],
] as const;

function Facilities() {
  return (
    <>
      <PageHero eyebrow="Infrastructure" title="Spaces to learn and grow" image={images.sports} />
      <Section eyebrow="Facilities" title="On our campus">
        <p className="mb-8 text-muted-foreground">Please confirm which facilities are available — only confirmed ones will be shown at launch. <Placeholder>Photos & details TBC</Placeholder></p>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {items.map(([I, t]) => <Card key={t} icon={<I size={20} />} title={t}><Placeholder /></Card>)}
        </div>
      </Section>
    </>
  );
}
