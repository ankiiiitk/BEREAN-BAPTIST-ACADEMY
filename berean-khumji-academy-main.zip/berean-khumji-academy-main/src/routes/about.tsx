import { createFileRoute } from "@tanstack/react-router";
import { PageHero, Section, Card, Placeholder, meta } from "@/components/site";
import { images } from "@/lib/school";

export const Route = createFileRoute("/about")({
  head: () => meta("About Us", "History, vision, values and leadership of Berean Baptist Academy, Khumji, Noney District, Manipur."),
  component: About,
});

function About() {
  return (
    <>
      <PageHero eyebrow="About Us" title="Our story, our purpose" image={images.hero} />
      <Section eyebrow="Introduction & History" title="Who we are">
        <p className="max-w-3xl text-lg text-muted-foreground">Berean Baptist Academy is a school in Khumji, Noney District, Manipur. Founding history and journey <Placeholder /></p>
      </Section>
      <Section tone="sage" eyebrow="Purpose" title="Vision, mission & values">
        <div className="grid gap-5 md:grid-cols-3">
          <Card title="Vision"><Placeholder /></Card>
          <Card title="Mission"><Placeholder /></Card>
          <Card title="Core values"><Placeholder /></Card>
        </div>
      </Section>
      <Section tone="white" eyebrow="Leadership" title="Principal & management">
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {["Principal", "Vice Principal", "Management Board", "Administration"].map((r) => (
            <div key={r} className="rounded-2xl border bg-background p-6 text-center">
              <div className="mx-auto mb-4 grid h-24 w-24 place-items-center rounded-full bg-secondary text-xs text-muted-foreground">Photo</div>
              <h3 className="text-xl">{r}</h3><Placeholder>Name TBC</Placeholder>
            </div>
          ))}
        </div>
      </Section>
      <Section eyebrow="Philosophy & Recognition" title="How we educate">
        <div className="grid gap-5 md:grid-cols-3">
          <Card title="Educational philosophy"><Placeholder /></Card>
          <Card title="Milestones"><Placeholder /></Card>
          <Card title="Affiliation & recognition"><Placeholder>Board / registration details TBC</Placeholder></Card>
        </div>
      </Section>
    </>
  );
}
