import { createFileRoute, Link } from "@tanstack/react-router";
import { BookOpen, Leaf, HeartHandshake, Users, FlaskConical, Monitor, Library, Trophy, ArrowRight, Quote } from "lucide-react";
import { Section, Card, Placeholder, meta } from "@/components/site";
import { images, school, announcements } from "@/lib/school";

export const Route = createFileRoute("/")({
  head: () => meta("Home", "Berean Baptist Academy in Khumji, Noney District, Manipur — a faith-rooted school nurturing knowledge, character and community."),
  component: Index,
});

function Index() {
  return (
    <>
      <section className="relative isolate min-h-[88vh] overflow-hidden">
        <img src={images.hero} alt="Berean Baptist Academy campus among the misty hills of Noney" className="absolute inset-0 -z-10 h-full w-full object-cover" width={1920} height={1088} />
        <div className="absolute inset-0 -z-10 bg-gradient-to-r from-primary/90 via-primary/60 to-transparent" />
        <div className="mx-auto flex min-h-[88vh] max-w-7xl flex-col justify-center px-5 py-24 fade-up">
          <p className="eyebrow">{school.location}</p>
          <h1 className="mt-4 max-w-3xl text-6xl leading-[1.02] text-primary-foreground md:text-8xl">{school.name}</h1>
          <p className="mt-6 max-w-xl text-xl text-primary-foreground/85">{school.tagline}</p>
          <div className="mt-10 flex flex-wrap gap-4">
            <Link to="/admissions" className="rounded-full bg-gold px-8 py-4 font-nav font-medium text-primary transition-transform hover:-translate-y-0.5">Admission Enquiry</Link>
            <Link to="/about" className="rounded-full border border-primary-foreground/40 px-8 py-4 font-nav font-medium text-primary-foreground hover:bg-primary-foreground/10">Discover the School</Link>
          </div>
        </div>
      </section>

      <Section eyebrow="Principal's Welcome" title="A message to our families">
        <div className="grid items-center gap-10 md:grid-cols-[280px_1fr]">
          <div className="grid aspect-[4/5] place-items-center rounded-2xl bg-secondary text-center"><Placeholder>Principal's photo</Placeholder></div>
          <div>
            <Quote className="text-gold" size={36} />
            <p className="mt-4 font-display text-2xl leading-relaxed text-slate md:text-3xl">The Principal's welcome message will appear here.</p>
            <p className="mt-6 font-nav text-sm text-muted-foreground">Principal's name <Placeholder /></p>
          </div>
        </div>
      </Section>

      <Section tone="white" eyebrow="About the School" title="Learning among the hills of Noney">
        <div className="grid gap-12 md:grid-cols-2">
          <div className="space-y-5 text-lg text-muted-foreground">
            <p>Berean Baptist Academy serves the community of Khumji and the wider Noney District, offering children a place to grow in knowledge, character and faith.</p>
            <p>History, founding year and affiliation details <Placeholder /></p>
            <Link to="/about" className="inline-flex items-center gap-2 font-nav font-medium text-primary hover:text-gold">Read our story <ArrowRight size={16} /></Link>
          </div>
          <div className="grid gap-5 sm:grid-cols-2">
            <Card title="Vision"><Placeholder /></Card>
            <Card title="Mission"><Placeholder /></Card>
          </div>
        </div>
      </Section>

      <Section tone="sage" eyebrow="Why Berean" title="What families can expect">
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          <Card icon={<HeartHandshake size={20} />} title="Values-led">Christian values guiding character and conduct.</Card>
          <Card icon={<Users size={20} />} title="Personal attention">Every child known by name.</Card>
          <Card icon={<Leaf size={20} />} title="Rooted locally">Celebrating the culture of our region.</Card>
          <Card icon={<BookOpen size={20} />} title="Strong foundations">Steady focus on core academics.</Card>
        </div>
      </Section>

      <Section eyebrow="Academics & Facilities" title="Where learning happens">
        <div className="grid gap-6 md:grid-cols-3">
          <Link to="/academics" className="group overflow-hidden rounded-2xl bg-card shadow-soft md:col-span-2">
            <img src={images.classroom} alt="Students studying in a classroom" loading="lazy" width={1200} height={912} className="h-72 w-full object-cover transition-transform duration-700 group-hover:scale-105" />
            <div className="p-7"><h3 className="text-3xl">Academic programmes</h3><p className="mt-2 text-muted-foreground">Classes offered and curriculum <Placeholder /></p></div>
          </Link>
          <div className="grid gap-4">
            {[[FlaskConical, "Science lab"], [Monitor, "Computer lab"], [Library, "Library"]].map(([I, t]) => {
              const Icon = I as typeof FlaskConical;
              return <Link key={t as string} to="/facilities" className="flex items-center gap-4 rounded-2xl border bg-card p-5 hover:border-gold"><Icon className="text-gold" /><span className="font-display text-xl text-primary">{t as string}</span></Link>;
            })}
          </div>
        </div>
      </Section>

      <Section tone="white" eyebrow="Student Life" title="Culture, sport and celebration">
        <div className="grid gap-6 md:grid-cols-2">
          {[[images.culture, "Cultural programmes", "Traditional dance performed at a school function"], [images.sports, "Sports & athletics", "Students playing football on the hillside ground"]].map(([src, t, alt]) => (
            <Link key={t} to="/student-life" className="group relative block overflow-hidden rounded-2xl">
              <img src={src} alt={alt} loading="lazy" width={1200} height={912} className="h-96 w-full object-cover transition-transform duration-700 group-hover:scale-105" />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/85 to-transparent" />
              <h3 className="absolute bottom-6 left-6 text-3xl text-primary-foreground">{t}</h3>
            </Link>
          ))}
        </div>
        <div className="mt-8 flex items-center gap-3 text-muted-foreground"><Trophy className="text-gold" /> Achievements and events <Placeholder /></div>
      </Section>

      <Section tone="sage" eyebrow="Parent Voices" title="Testimonials">
        <div className="rounded-2xl border border-dashed border-gold bg-card/60 p-10 text-center text-muted-foreground">Real testimonials from parents will be added here once collected. <Placeholder /></div>
      </Section>

      <Section eyebrow="Notice Board" title="Latest announcements">
        <div className="grid gap-5 md:grid-cols-3">
          {announcements.map((a) => (
            <article key={a.title} className="rounded-2xl border bg-card p-7">
              <p className="eyebrow">{a.cat}</p>
              <h3 className="mt-2 text-2xl">{a.title}</h3>
              <p className="mt-2 text-muted-foreground">{a.body}</p>
            </article>
          ))}
        </div>
        <Link to="/news" className="mt-8 inline-flex items-center gap-2 font-nav font-medium text-primary hover:text-gold">All news <ArrowRight size={16} /></Link>
      </Section>

      <section className="bg-slate py-20">
        <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-6 px-5 md:flex-row md:items-center">
          <div><p className="eyebrow">Admissions</p><h2 className="mt-2 text-4xl text-primary-foreground md:text-5xl">Begin your child's journey with us</h2></div>
          <Link to="/admissions" className="rounded-full bg-gold px-8 py-4 font-nav font-medium text-primary">Make an Enquiry</Link>
        </div>
      </section>
    </>
  );
}
