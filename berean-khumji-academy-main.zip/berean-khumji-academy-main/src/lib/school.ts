import hero from "@/assets/hero-campus.jpg";
import classroom from "@/assets/classroom.jpg";
import culture from "@/assets/culture.jpg";
import sports from "@/assets/sports.jpg";

export const images = { hero, classroom, culture, sports };

/** Values marked TBC are placeholders awaiting confirmation from the school. */
export const school = {
  name: "Berean Baptist Academy",
  short: "BBA",
  tagline: "Rooted in faith, growing in knowledge",
  location: "Khumji, Noney District, Manipur",
  address: "Berean Baptist Academy, Khumji, Noney District, Manipur – PIN (TBC)",
  phone: "+91 00000 00000 (TBC)",
  whatsapp: "910000000000",
  email: "info@bereanbaptistacademy.example (TBC)",
  hours: "Mon – Fri: 8:30 AM – 3:30 PM · Sat: 8:30 AM – 12:30 PM (TBC)",
  mapQuery: "Khumji, Noney, Manipur",
};

export const nav = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About" },
  { to: "/academics", label: "Academics" },
  { to: "/admissions", label: "Admissions" },
  { to: "/facilities", label: "Facilities" },
  { to: "/student-life", label: "Student Life" },
  { to: "/gallery", label: "Gallery" },
  { to: "/news", label: "News" },
  { to: "/contact", label: "Contact" },
] as const;

export const announcements = [
  { date: "Placeholder", cat: "Admissions", title: "Admission enquiries for the new academic session", body: "Dates and details to be confirmed by the school office." },
  { date: "Placeholder", cat: "Examinations", title: "Examination schedule", body: "The schedule will be published here once finalised." },
  { date: "Placeholder", cat: "Holidays", title: "Holiday list", body: "The official holiday list for the year will be shared soon." },
];

export const classesOffered = ["Class (TBC)"];
