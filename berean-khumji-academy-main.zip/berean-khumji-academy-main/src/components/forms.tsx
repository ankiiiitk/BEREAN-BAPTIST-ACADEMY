import { useState, type FormEvent } from "react";
import { z } from "zod";
import { CheckCircle2 } from "lucide-react";

type Field = { name: string; label: string; type?: string; required?: boolean; textarea?: boolean; options?: string[] };

const field = "w-full rounded-xl border border-input bg-card px-4 py-3 text-foreground outline-none focus:border-gold focus:ring-2 focus:ring-ring/30";

export function EnquiryForm({ fields, schema, submitLabel }: { fields: Field[]; schema: z.ZodTypeAny; submitLabel: string }) {
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [done, setDone] = useState(false);

  function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.currentTarget));
    const r = schema.safeParse(data);
    if (!r.success) {
      const errs: Record<string, string> = {};
      for (const i of r.error.issues) errs[String(i.path[0])] ??= i.message;
      setErrors(errs);
      return;
    }
    setErrors({});
    setDone(true);
  }

  if (done)
    return (
      <div role="status" className="rounded-2xl border bg-card p-10 text-center shadow-soft">
        <CheckCircle2 className="mx-auto text-primary" size={40} />
        <h3 className="mt-4 text-3xl">Thank you</h3>
        <p className="mt-2 text-muted-foreground">Your details look good. Online submission is being set up — for now, please also call or WhatsApp the school office to confirm your enquiry.</p>
      </div>
    );

  return (
    <form noValidate onSubmit={onSubmit} className="grid gap-5 rounded-2xl border bg-card p-7 shadow-soft md:grid-cols-2">
      {fields.map((f) => (
        <label key={f.name} className={`block ${f.textarea ? "md:col-span-2" : ""}`}>
          <span className="mb-1.5 block font-nav text-sm font-medium text-slate">{f.label}{f.required && <span className="text-gold"> *</span>}</span>
          {f.textarea ? (
            <textarea name={f.name} rows={4} className={field} aria-invalid={!!errors[f.name]} />
          ) : f.options ? (
            <select name={f.name} className={field} defaultValue="" aria-invalid={!!errors[f.name]}>
              <option value="" disabled>Select…</option>
              {f.options.map((o) => <option key={o}>{o}</option>)}
            </select>
          ) : (
            <input name={f.name} type={f.type ?? "text"} className={field} aria-invalid={!!errors[f.name]} />
          )}
          {errors[f.name] && <span className="mt-1 block text-sm text-destructive">{errors[f.name]}</span>}
        </label>
      ))}
      <button type="submit" className="rounded-full bg-primary px-8 py-3.5 font-nav font-medium text-primary-foreground transition-colors hover:bg-slate md:col-span-2 md:justify-self-start">{submitLabel}</button>
    </form>
  );
}

const phone = z.string().trim().regex(/^[+\d\s-]{10,15}$/, "Enter a valid phone number");
const email = z.string().trim().email("Enter a valid email").max(255);

export const admissionSchema = z.object({
  student: z.string().trim().min(2, "Enter the student's name").max(100),
  dob: z.string().min(1, "Enter date of birth"),
  parent: z.string().trim().min(2, "Enter parent/guardian name").max(100),
  klass: z.string().min(1, "Choose a class"),
  phone,
  email,
  current: z.string().max(150).optional(),
  message: z.string().max(1000).optional(),
});

export const contactSchema = z.object({
  name: z.string().trim().min(2, "Enter your name").max(100),
  email,
  phone: phone.or(z.literal("")),
  message: z.string().trim().min(5, "Enter a message").max(1000),
});
