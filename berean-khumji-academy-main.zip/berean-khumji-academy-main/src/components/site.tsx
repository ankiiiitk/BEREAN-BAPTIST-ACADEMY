import { Link } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import { Menu, X, MessageCircle, Phone, Mail, MapPin, Facebook, Instagram, Youtube } from "lucide-react";
import { nav, school } from "@/lib/school";

export function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const f = () => setScrolled(window.scrollY > 20);
    f();
    window.addEventListener("scroll", f);
    return () => window.removeEventListener("scroll", f);
  }, []);
  return (
    <header className={`sticky top-0 z-50 transition-all ${scrolled ? "bg-background/95 shadow-soft backdrop-blur" : "bg-background"}`}>
      <div className="mx-auto flex h-18 max-w-7xl items-center justify-between px-5 py-3">
        <Link to="/" className="flex items-center gap-3" onClick={() => setOpen(false)}>
          <span className="grid h-11 w-11 place-items-center rounded-full bg-primary font-display text-lg text-primary-foreground">B</span>
          <span className="leading-tight">
            <span className="block font-display text-xl font-semibold text-primary">{school.name}</span>
            <span className="block font-nav text-[11px] tracking-widest text-muted-foreground uppercase">Khumji · Noney</span>
          </span>
        </Link>
        <nav className="hidden items-center gap-1 xl:flex" aria-label="Main">
          {nav.map((n) => (
            <Link key={n.to} to={n.to} activeOptions={{ exact: n.to === "/" }}
              className="rounded-full px-3 py-2 font-nav text-sm font-medium text-slate transition-colors hover:text-primary data-[status=active]:bg-secondary data-[status=active]:text-primary">
              {n.label}
            </Link>
          ))}
        </nav>
        <button className="rounded-full p-2 text-primary xl:hidden" aria-label={open ? "Close menu" : "Open menu"} aria-expanded={open} onClick={() => setOpen(!open)}>
          {open ? <X /> : <Menu />}
        </button>
      </div>
      {open && (
        <nav className="border-t bg-background px-5 pb-6 xl:hidden" aria-label="Mobile">
          {nav.map((n) => (
            <Link key={n.to} to={n.to} onClick={() => setOpen(false)} activeOptions={{ exact: n.to === "/" }}
              className="block border-b py-3 font-nav font-medium text-slate data-[status=active]:text-primary">
              {n.label}
            </Link>
          ))}
          <Link to="/admissions" onClick={() => setOpen(false)} className="mt-5 block rounded-full bg-primary py-3 text-center font-nav font-medium text-primary-foreground">Admission Enquiry</Link>
        </nav>
      )}
    </header>
  );
}

export function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="mx-auto grid max-w-7xl gap-10 px-5 py-16 md:grid-cols-4">
        <div className="md:col-span-2">
          <p className="font-display text-3xl">{school.name}</p>
          <p className="mt-2 text-primary-foreground/70">{school.tagline}</p>
          <div className="mt-6 flex gap-3">
            {[Facebook, Instagram, Youtube].map((I, i) => (
              <a key={i} href="#" aria-label="Social media (link to be added)" className="grid h-10 w-10 place-items-center rounded-full border border-primary-foreground/20 hover:border-gold hover:text-gold"><I size={18} /></a>
            ))}
          </div>
        </div>
        <div>
          <p className="eyebrow">Explore</p>
          <ul className="mt-4 space-y-2 text-sm text-primary-foreground/80">
            {nav.slice(1).map((n) => <li key={n.to}><Link to={n.to} className="hover:text-gold">{n.label}</Link></li>)}
          </ul>
        </div>
        <div>
          <p className="eyebrow">Contact</p>
          <ul className="mt-4 space-y-3 text-sm text-primary-foreground/80">
            <li className="flex gap-2"><MapPin size={16} className="mt-0.5 shrink-0" />{school.location}</li>
            <li className="flex gap-2"><Phone size={16} className="mt-0.5 shrink-0" />{school.phone}</li>
            <li className="flex gap-2"><Mail size={16} className="mt-0.5 shrink-0" /><span className="break-all">{school.email}</span></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-primary-foreground/10 py-5 text-center text-xs text-primary-foreground/60">© {new Date().getFullYear()} {school.name}. All rights reserved.</div>
    </footer>
  );
}

export function WhatsAppButton() {
  return (
    <a href={`https://wa.me/${school.whatsapp}`} target="_blank" rel="noreferrer" aria-label="Chat on WhatsApp"
      className="fixed right-5 bottom-5 z-40 grid h-14 w-14 place-items-center rounded-full bg-gold text-primary shadow-soft transition-transform hover:scale-105">
      <MessageCircle />
    </a>
  );
}

export function PageHero({ eyebrow, title, intro, image }: { eyebrow: string; title: string; intro?: string; image: string }) {
  return (
    <section className="relative isolate overflow-hidden">
      <img src={image} alt="" className="absolute inset-0 -z-10 h-full w-full object-cover" width={1920} height={1088} />
      <div className="absolute inset-0 -z-10 bg-primary/75" />
      <div className="mx-auto max-w-7xl px-5 py-24 md:py-32 fade-up">
        <p className="eyebrow">{eyebrow}</p>
        <h1 className="mt-3 max-w-3xl text-5xl text-primary-foreground md:text-6xl">{title}</h1>
        {intro && <p className="mt-5 max-w-2xl text-lg text-primary-foreground/80">{intro}</p>}
      </div>
    </section>
  );
}

export function Section({ eyebrow, title, children, tone = "ivory", id }: { eyebrow?: string; title?: string; children: ReactNode; tone?: "ivory" | "sage" | "white"; id?: string }) {
  const bg = tone === "sage" ? "bg-secondary" : tone === "white" ? "bg-card" : "bg-background";
  return (
    <section id={id} className={`${bg} py-20 md:py-24`}>
      <div className="mx-auto max-w-7xl px-5">
        {eyebrow && <p className="eyebrow">{eyebrow}</p>}
        {title && <h2 className="mt-2 mb-10 max-w-3xl text-4xl md:text-5xl">{title}</h2>}
        {children}
      </div>
    </section>
  );
}

export function Card({ title, children, icon }: { title: string; children?: ReactNode; icon?: ReactNode }) {
  return (
    <div className="rounded-2xl border bg-card p-7 shadow-soft transition-transform hover:-translate-y-1">
      {icon && <div className="mb-4 grid h-11 w-11 place-items-center rounded-full bg-secondary text-primary">{icon}</div>}
      <h3 className="text-2xl">{title}</h3>
      {children && <div className="mt-2 text-muted-foreground">{children}</div>}
    </div>
  );
}

export function Placeholder({ children = "Content to be provided by the school" }: { children?: ReactNode }) {
  return <span className="placeholder-tag">{children}</span>;
}

export function meta(title: string, description: string) {
  return {
    meta: [
      { title: `${title} | Berean Baptist Academy` },
      { name: "description", content: description },
      { property: "og:title", content: `${title} | Berean Baptist Academy` },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  };
}
